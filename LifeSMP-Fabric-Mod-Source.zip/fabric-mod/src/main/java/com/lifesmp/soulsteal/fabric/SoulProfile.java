package com.lifesmp.soulsteal.fabric;

import java.util.EnumMap;
import java.util.Map;

final class SoulProfile {
    SoulType equipped;
    final EnumMap<SoulType,Integer> stored = new EnumMap<>(SoulType.class);
    boolean isEmpty() { return equipped == null && stored.isEmpty(); }
    void add(SoulType t) { stored.merge(t, 1, Integer::sum); }
    boolean take(SoulType t) {
        int n = stored.getOrDefault(t,0);
        if (n <= 0) return false;
        if (n == 1) stored.remove(t); else stored.put(t,n-1);
        return true;
    }
}
