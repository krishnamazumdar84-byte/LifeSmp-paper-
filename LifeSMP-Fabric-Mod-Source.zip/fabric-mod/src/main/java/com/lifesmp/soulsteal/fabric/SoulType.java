package com.lifesmp.soulsteal.fabric;

public enum SoulType {
    FROST("Frost"), WIND("Wind"), FLAME("Flame"), SHADOW("Shadow"), LIGHT("Light"),
    THUNDER("Thunder"), EARTH("Earth"), OCEAN("Ocean"), VOID("Void"), SPIRIT("Spirit");
    public final String title;
    SoulType(String title) { this.title = title; }
    public static SoulType parse(String value) {
        try { return value == null ? null : valueOf(value.toUpperCase(java.util.Locale.ROOT)); }
        catch (IllegalArgumentException e) { return null; }
    }
}
