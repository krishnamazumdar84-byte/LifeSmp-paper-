package com.lifesmp.soulsteal.fabric;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class SoulStealMod implements ModInitializer {
    static final Map<UUID, SoulProfile> DATA = new HashMap<>();
    static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
    static final Set<UUID> INITIALIZED = new HashSet<>();
    static MinecraftServer server;
    static Path saveFile;
    static final int COOLDOWN_SECONDS = 45;

    @Override public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            server = s;
            saveFile = s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("lifesmp-souls.properties");
            load();
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> save());
        ServerPlayConnectionEvents.JOIN.register((handler, sender, s) -> {
            ServerPlayer p = handler.player;
            SoulProfile profile = DATA.computeIfAbsent(p.getUUID(), id -> new SoulProfile());
            if (INITIALIZED.add(p.getUUID())) {
                if (profile.isEmpty()) {
                    SoulType[] all = SoulType.values();
                    profile.equipped = all[new Random().nextInt(all.length)];
                    p.sendSystemMessage(Component.literal("Your starting Soul is " + profile.equipped.title + "!"));
                }
                save();
            }
            hud(p);
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof ServerPlayer victim)) return;
            Entity attacker = source.getEntity();
            if (!(attacker instanceof ServerPlayer killer) || killer == victim) return; // environmental death: no transfer
            SoulProfile v = profile(victim), k = profile(killer);
            if (v.equipped == null) return;
            SoulType stolen = v.equipped;
            v.equipped = null;
            if (k.equipped == null) k.equipped = stolen; else k.add(stolen);
            victim.sendSystemMessage(Component.literal("Your equipped " + stolen.title + " Soul was stolen."));
            killer.sendSystemMessage(Component.literal("You stole " + stolen.title + " Soul!"));
            save();
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) ->
            dispatcher.register(Commands.literal("soul")
                .executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    SoulProfile data = profile(p);
                    p.sendSystemMessage(Component.literal("Equipped: " + (data.equipped == null ? "None" : data.equipped.title)));
                    for (SoulType t : SoulType.values()) {
                        int n = data.stored.getOrDefault(t, 0);
                        if (n > 0) p.sendSystemMessage(Component.literal(t.title + " x" + n));
                    }
                    p.sendSystemMessage(Component.literal("Use the Soul Menu keybind to equip; Ability keybind activates your equipped Soul."));
                    return 1;
                })
                .then(Commands.literal("equip").then(Commands.argument("type", StringArgumentType.word()).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    SoulType type = SoulType.parse(StringArgumentType.getString(ctx,"type"));
                    if (type == null || !profile(p).take(type)) {
                        p.sendSystemMessage(Component.literal("You do not have that stored Soul."));
                        return 0;
                    }
                    SoulProfile data = profile(p);
                    if (data.equipped != null) data.add(data.equipped);
                    data.equipped = type;
                    save();
                    p.sendSystemMessage(Component.literal("Equipped " + type.title + " Soul."));
                    hud(p);
                    return 1;
                })))
                .then(Commands.literal("unequip").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    SoulProfile data = profile(p);
                    if (data.equipped == null) { p.sendSystemMessage(Component.literal("You have no equipped Soul.")); return 0; }
                    data.add(data.equipped); data.equipped = null; save(); hud(p);
                    p.sendSystemMessage(Component.literal("Soul moved to storage."));
                    return 1;
                }))
                .then(Commands.literal("give")
                    .then(Commands.argument("type", StringArgumentType.word())
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            SoulType type = SoulType.parse(StringArgumentType.getString(ctx,"type"));
                            if (type == null) { p.sendSystemMessage(Component.literal("Unknown Soul type.")); return 0; }
                            profile(p).add(type); save();
                            p.sendSystemMessage(Component.literal("Added one " + type.title + " Soul to storage."));
                            return 1;
                        })
                        .then(Commands.argument("amount", IntegerArgumentType.integer(1,64)).executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            SoulType type = SoulType.parse(StringArgumentType.getString(ctx,"type"));
                            if (type == null) { p.sendSystemMessage(Component.literal("Unknown Soul type.")); return 0; }
                            int amount = IntegerArgumentType.getInteger(ctx,"amount");
                            for (int i=0;i<amount;i++) profile(p).add(type);
                            save(); p.sendSystemMessage(Component.literal("Added " + amount + " " + type.title + " Soul(s)."));
                            return 1;
                        }))
                    ))
                .then(Commands.literal("ability").executes(ctx -> {
                    activate(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
            )
        );
    }

    static SoulProfile profile(ServerPlayer p) { return DATA.computeIfAbsent(p.getUUID(), id -> new SoulProfile()); }

    static void activate(ServerPlayer p) {
        SoulProfile data = profile(p);
        SoulType soul = data.equipped;
        if (soul == null) { p.sendSystemMessage(Component.literal("You have no equipped Soul.")); return; }
        long now = System.currentTimeMillis(), ready = COOLDOWNS.getOrDefault(p.getUUID(), 0L);
        if (now < ready) { p.sendSystemMessage(Component.literal("Ability cooldown: " + ((ready-now+999)/1000) + "s")); return; }
        int ticks = 120;
        boolean success = true;
        switch (soul) {
            case FROST -> {
                ServerPlayer target = p.serverLevel().players().stream().filter(t -> t != p && t.distanceToSqr(p) <= 36)
                    .min(Comparator.comparingDouble(t -> t.distanceToSqr(p))).orElse(null);
                if (target == null) success = false;
                else target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 0));
            }
            case WIND -> p.setDeltaMovement(p.getLookAngle().normalize().scale(1.25).add(0,0.35,0));
            case FLAME -> p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, ticks, 0));
            case SHADOW -> p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, ticks, 0));
            case LIGHT -> p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
            case THUNDER -> p.addEffect(new MobEffectInstance(MobEffects.SPEED, ticks, 0));
            case EARTH -> p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 100, 0));
            case OCEAN -> p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 240, 0));
            case VOID -> {
                Vec3 dest = p.position().add(p.getLookAngle().normalize().scale(3));
                BlockPosCheck check = new BlockPosCheck(p, dest);
                if (!check.safe()) success = false; else p.teleportTo(dest.x, dest.y, dest.z);
            }
            case SPIRIT -> {
                List<ServerPlayer> targets = p.serverLevel().players().stream().filter(t -> t != p && t.distanceToSqr(p) <= 64).toList();
                if (targets.isEmpty()) success = false;
                for (ServerPlayer t : targets) t.addEffect(new MobEffectInstance(MobEffects.GLOWING, 80, 0));
            }
        }
        if (!success) { p.sendSystemMessage(Component.literal("No nearby target or safe space found.")); return; }
        COOLDOWNS.put(p.getUUID(), now + COOLDOWN_SECONDS * 1000L);
        p.sendSystemMessage(Component.literal(soul.title + " ability activated."));
        hud(p);
    }

    static void hud(ServerPlayer p) {
        SoulType current = profile(p).equipped;
        p.displayClientMessage(Component.literal("Soul: " + (current == null ? "None" : current.title) + " | F: Ability | K: Menu"), true);
    }

    private record BlockPosCheck(ServerPlayer player, Vec3 pos) {
        boolean safe() {
            var level = player.serverLevel();
            var a = net.minecraft.core.BlockPos.containing(pos);
            var b = a.above();
            return level.getBlockState(a).getCollisionShape(level,a).isEmpty()
                && level.getBlockState(b).getCollisionShape(level,b).isEmpty();
        }
    }

    static void load() {
        if (saveFile == null || !Files.exists(saveFile)) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(saveFile)) { props.load(in); } catch (IOException ignored) { return; }
        for (String key : props.stringPropertyNames()) {
            String[] bits = key.split("\\|");
            if (bits.length < 2) continue;
            try {
                UUID id = UUID.fromString(bits[0]);
                if (bits[1].equals("initialized")) { INITIALIZED.add(id); continue; }
                if (bits.length < 3) continue;
                SoulType type = SoulType.valueOf(bits[2]);
                SoulProfile p = DATA.computeIfAbsent(id, x -> new SoulProfile());
                if (bits[1].equals("equipped")) p.equipped = type;
                else if (bits[1].equals("stored") && bits.length >= 3) p.stored.put(type, Integer.parseInt(props.getProperty(key)));
            } catch (Exception ignored) { }
        }
    }
    static void save() {
        if (saveFile == null) return;
        Properties props = new Properties();
        INITIALIZED.forEach(id -> props.setProperty(id + "|initialized", "true"));
        DATA.forEach((id,p) -> {
            if (p.equipped != null) props.setProperty(id + "|equipped|" + p.equipped.name(), "true");
            p.stored.forEach((type,n) -> props.setProperty(id + "|stored|" + type.name(), String.valueOf(n)));
        });
        try {
            Files.createDirectories(saveFile.getParent());
            try (OutputStream out = Files.newOutputStream(saveFile)) { props.store(out, "LifeSMP SoulSteal"); }
        } catch (IOException ignored) { }
    }

}
