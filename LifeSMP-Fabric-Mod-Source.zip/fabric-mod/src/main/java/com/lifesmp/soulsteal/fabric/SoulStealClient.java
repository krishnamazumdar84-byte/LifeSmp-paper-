package com.lifesmp.soulsteal.fabric;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public final class SoulStealClient implements ClientModInitializer {
    private static KeyMapping abilityKey;
    private static KeyMapping menuKey;
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
        Identifier.fromNamespaceAndPath("lifesmp_soulsteal", "controls"));

    @Override public void onInitializeClient() {
        abilityKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.lifesmp_soulsteal.ability", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F, CATEGORY));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.lifesmp_soulsteal.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (abilityKey.consumeClick()) {
                if (client.player != null) client.player.connection.sendCommand("soul ability");
            }
            while (menuKey.consumeClick()) {
                if (client.player != null) client.setScreen(new SoulMenuScreen());
            }
        });
    }

    private static final class SoulMenuScreen extends Screen {
        SoulMenuScreen() { super(Component.literal("LifeSMP Soul Inventory")); }
        @Override protected void init() {
            int left = this.width / 2 - 100, top = this.height / 4;
            int y = top;
            addRenderableWidget(Button.builder(Component.literal("Unequip current Soul"),
                button -> {
                    if (minecraft.player != null) minecraft.player.connection.sendCommand("soul unequip");
                    onClose();
                }).bounds(left, y, 200, 20).build());
            y += 22;
            for (SoulType type : SoulType.values()) {
                SoulType selected = type;
                addRenderableWidget(Button.builder(Component.literal("Equip " + type.title),
                    button -> {
                        if (minecraft.player != null) minecraft.player.connection.sendCommand("soul equip " + selected.name());
                        onClose();
                    }).bounds(left, y, 200, 20).build());
                y += 22;
            }
            addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(left, Math.min(y + 4, this.height - 26), 200, 20).build());
        }
        @Override public boolean isPauseScreen() { return false; }
    }
}
