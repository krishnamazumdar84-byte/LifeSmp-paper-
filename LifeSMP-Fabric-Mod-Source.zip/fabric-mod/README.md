# Fabric mod — Minecraft 1.21.11

Requires Fabric Loader 0.18.1+, Fabric API 0.141.1+1.21.11, Java 21.

Build with `gradle build`. Output: `build/libs/lifesmp-soulsteal-fabric-1.0.0.jar`.

In-game:
- Press K to open the Soul selection screen.
- Press F to activate your equipped Soul.
- `/soul` prints equipped and stored Soul counts.
- `/soul give FROST [amount]` gives your player stored Souls for single-player testing.
- `/soul unequip` moves your active Soul into storage.
- The mod registers server-side Soul data in the single-player world's `lifesmp-souls.properties`.

The menu is intentionally a simple client screen; it sends equip commands to the integrated server. It is a first implementation and needs in-game testing before use in an important world. Back up your world first.
